import React, {Component} from 'react';
import Navigation from './Navigation';

class Cocina extends Component{
    
    render(){
        return (
            <React.Fragment>
                <Navigation></Navigation>
                <h1>COCINA</h1>
            </React.Fragment>
        );

    }
}

export default Cocina;